/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sabadoletivo2705;

import java.util.Date;

/**
 *
 * @author 1986334
 */
public class Sabadoletivo2705 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*System.out.println("-----Início do programa-----");
        Pessoa p = new Pessoa("João da Silva", "000.000.000-21",35);
        
        //String nomeDaPessoa = p.nome;
        System.out.println("O nome da pessoa é: "+p.nome);
        System.out.println("O cpf da pessoa é: "+p.cpf);
        System.out.println("A idade da pessoa é: "+p.idade);
        
        System.out.println("-----MUDEI O NOME-----");
        p.nome = "Luana Inácia Lula da Silva";
        
        System.out.println("O nome da pessoa é: "+p.nome);
        System.out.println("O cpf da pessoa é: "+p.cpf);
        System.out.println("A idade da pessoa é: "+p.idade);
        
        System.out.println("-----Fim do programa-----");*/
        
        System.out.println("-----Início do programa-----");
        Date lancamento = new Date(113,8,17);
        System.out.println(lancamento);
        
        Game g1 = new Game("GTA V", "Rockstar","Ação","+18",
                "PC/PS3/PS4/XBOX*",lancamento);
        //g1.nome = "GTA";
        //g1.distribuidora = "Rockstar Games";
        System.out.println("Nome do jogo:"+g1.nome);
        System.out.println("Dist. do jogo:"+g1.distribuidora);
        System.out.println("Classificação: "+g1.classificacao);
        
        Date lancamentoLol = new Date(109,9,27);
        Game g2 = new Game("LoL","Riot Games",
                "MOBA","+2","PC(Windows)",
                lancamentoLol);
        //g2.nome = "LoL";
        //g2.distribuidora = "Riot Games";
        System.out.println("Meus games: "+g1.nome+","+g2.nome);
        System.out.println("Classificação:"+g2.classificacao);
    }
    
}
