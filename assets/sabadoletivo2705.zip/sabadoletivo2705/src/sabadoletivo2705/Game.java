package sabadoletivo2705;

import java.util.Date;

public class Game {
    public String nome;
    public String distribuidora;
    public String genero;
    public String classificacao;
    public String plataformas;
    public Date dataDeLancamento;
    
    /*public Game(){
        nome = "Nome padrão";
        genero = "genero padrao";
        distribuidora = "dist. padrao";
        classificacao = "Livre";
        plataformas = "PC";
        dataDeLancamento = new Date();
    }*/

    public Game(String nome, String distribuidora,
            String genero, String classificacao, 
            String plataformas, 
            Date dataDeLancamento) {
        this.nome = nome;
        this.distribuidora = distribuidora;
        this.genero = genero;
        this.classificacao = classificacao;
        this.plataformas = plataformas;
        this.dataDeLancamento = dataDeLancamento;
    }
    
    
    
    
  
 }
