/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sabadoletivo2705;

/**
 *
 * @author 1986334
 */
public class Pessoa {
    public String nome;
    public String cpf;
    public int idade;
    
    public Pessoa(String n, String cpf, int idade){
        nome = n;
        this.cpf = cpf;
        this.idade = idade;
    }
  }
