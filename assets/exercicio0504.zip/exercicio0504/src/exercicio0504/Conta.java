/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio0504;

/**
 *
 * @author 1986334
 */
public class Conta {
    String nome;
    String cpf;
    double saldo;
    
    void sacar(double valor){
        if (valor <= saldo) {
            if (valor > 0){
                saldo = saldo - valor;
            }else{
                System.out.println("Tentando sacar valor negativo...");
            }
        }else{
            System.out.println("Operação não permitida.");
        }
    }
    
    void depositar(double valor){
        if (valor > 0){
            saldo = saldo + valor;
        }else{
            System.out.println("Tentando depositar valor negativo...");
        }
    }
    
    void visualiza(){
        System.out.println("O saldo é: "+saldo);
    }
}
