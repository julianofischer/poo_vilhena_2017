/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio0504;

/**
 *
 * @author 1986334
 */
public class Ponto {
    int x;
    int y;
    
    public Ponto(){
        x = 1;
        y = 1;        
    }
    public Ponto(int x, int y){
        this.x = x;
        this.y = y;
                
    }
    
    double calculaDistancia(Ponto p){
        int ladox, ladoy;
        ladox = Math.abs(this.x - p.x);
        ladoy = Math.abs(this.y - p.y);
        //double h = Math.sqrt(ladox*ladox + ladoy*ladoy);
        double h = Math.sqrt(Math.pow(ladox, 2) + Math.pow(ladoy, 2));
        return h;
    }
}
