/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio0504;

/**
 *
 * @author 1986334
 */
public class Exercicio0504 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Conta c = new Conta();
        c.visualiza();//0
        c.depositar(-200);
        c.visualiza();//200
        c.sacar(100);
        c.visualiza();//100
        c.sacar(-300);//Operação não permitida
        c.visualiza();//100
        c.depositar(200);
        c.visualiza();//300
        c.saldo = -1000;
        c.visualiza();*/
        
        Ponto p1,p2;
        p1 = new Ponto();
        p2 = new Ponto(3,3);
        System.out.println(p1.calculaDistancia(p2));
        
    }
    
}
