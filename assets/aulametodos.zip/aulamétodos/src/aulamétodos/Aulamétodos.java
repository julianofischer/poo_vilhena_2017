/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulamétodos;

/**
 *
 * @author 1986334
 */
public class Aulamétodos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           Retangulo r = new Retangulo();
           r.ladoA = 3;
           r.ladoB = 5;
           int area = r.calculaArea();
           System.out.println("A área é: "+area);
                   
           int perimetro = r.caculaPerimetro();
           System.out.println("O perímetro é: "+perimetro);
           
           
           Triangulo t = new Triangulo();
           t.base = 2;
           t.h = 2;
           t.ladoA = 2;
           t.ladoB = 2;
           System.out.println(t.calculaArea());
           System.out.println(t.calculaPerimetro());
           
           System.out.println(Math.PI);
           
           Circulo c = new Circulo(2);
           System.out.println(c.calculaArea());
           System.out.println(c.calculaPerimetro());
    }
    
}
