/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulamétodos;

/**
 *
 * @author 1986334
 */
class Retangulo {
    int ladoA;
    int ladoB;
    
    int calculaArea(){
        int area =  ladoA * ladoB;
        return area;
    }
    
    int caculaPerimetro(){
        int perimetro = ladoA + ladoA  + ladoB + ladoB;
        return perimetro;
    }
    
    public static void main(String[] args) {
        System.out.println("método em retangulo");
    }
}
