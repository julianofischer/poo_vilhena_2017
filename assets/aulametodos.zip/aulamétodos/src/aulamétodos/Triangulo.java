/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulamétodos;

/**
 *
 * @author 1986334
 */
class Triangulo {
    int base;
    int h;
    int ladoA;
    int ladoB;
    
    double calculaArea(){
        return (base * h)/2;
    }
    
    double calculaPerimetro(){
        return base+ladoA+ladoB;
    }
}
