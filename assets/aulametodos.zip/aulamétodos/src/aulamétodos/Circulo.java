/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulamétodos;

/**
 *
 * @author 1986334
 */
class Circulo {
    int raio;
    
    public Circulo(){
        //default
    }
    
    public Circulo(int r){
        //método construtor que inicializa raio
        raio = r;
    }
    
    double calculaArea(){
        //return 3.14 * raio * raio;
        //return 3.14 * Math.pow(raio,2);
        return Math.PI * Math.pow(raio, 2);         
    }
    
    double calculaPerimetro(){
        return 2 * Math.PI * raio;
    }
}
